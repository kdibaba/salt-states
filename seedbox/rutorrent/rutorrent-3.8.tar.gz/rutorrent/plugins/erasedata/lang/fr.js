﻿/*
 * PLUGIN ERASEDATA
 *
 * French language file.
 *
 * Author: 
 */

 theUILang.Rem_torrents_content_prompt		= "Voulez-vous vraiment effacer le(s) torrent(s) sélectionné(s) ? ATTENTION : Ceci va supprimer le contenu du torrent.";
 theUILang.Delete_data_with_path		= "Supprimer le chemin";
 theUILang.Rem_torrents_with_path_prompt	= "Voulez-vous vraiment effacer le(s) torrent(s) sélectionné(s) ? ATTENTION : Ceci va supprimer tous les fichiers dans le dossier actuel du torrent.";

thePlugins.get("erasedata").langLoaded();
