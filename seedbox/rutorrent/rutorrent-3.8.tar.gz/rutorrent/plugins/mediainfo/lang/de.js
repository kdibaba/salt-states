﻿/*
 * PLUGIN MEDIAINFO
 *
 * German language file.
 *
 * Author: 
 */

 theUILang.mediainfo		= "Media Info";