﻿/*
 * PLUGIN MEDIAINFO
 *
 * Greek language file.
 *
 * Author: Chris Kanatas (ckanatas@gmail.com)
 */

 theUILang.mediainfo		= "Media Info";