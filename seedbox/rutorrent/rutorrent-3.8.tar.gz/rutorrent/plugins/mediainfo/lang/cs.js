﻿/*
 * PLUGIN MEDIAINFO
 *
 * Czech language file.
 *
 * Author: 
 */

 theUILang.mediainfo		= "Media Info";