﻿/*
 * PLUGIN MEDIAINFO
 *
 * Norwegian language file.
 *
 * Author: 
 */

 theUILang.mediainfo		= "Media Info";