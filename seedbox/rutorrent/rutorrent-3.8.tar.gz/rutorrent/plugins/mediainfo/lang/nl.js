﻿/*
 * PLUGIN MEDIAINFO
 *
 * Dutch language file.
 *
 * Author: 
 */

 theUILang.mediainfo		= "Media Info";