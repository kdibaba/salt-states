﻿/*
 * PLUGIN MEDIAINFO
 *
 * Korean language file.
 *
 * Author: Limerainne (limerainne@gmail.com)
 */

 theUILang.mediainfo		= "미디어 정보";
