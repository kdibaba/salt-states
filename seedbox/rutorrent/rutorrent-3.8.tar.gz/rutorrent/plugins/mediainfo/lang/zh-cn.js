﻿/*
 * PLUGIN MEDIAINFO
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.mediainfo		= "媒体信息";
