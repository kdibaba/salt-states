﻿/*
 * PLUGIN MEDIAINFO
 *
 * Turkish language file.
 *
 * Author: 
 */

 theUILang.mediainfo		= "Media Info";