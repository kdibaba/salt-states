<?php

$pathToExternals['mediainfo'] = '';		// Something like /usr/bin/mediainfo. If empty, will be found in PATH.
