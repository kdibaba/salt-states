﻿/*
 * PLUGIN RATIO
 *
 * German language file.
 *
 * Author: Dario Rugani (kontakt@rugani.de)
 */

 theUILang.ratios		= "Ratio Gruppen";
 theUILang.ratio		= "Ratio Gruppe";
 theUILang.mnuRatio		= "Setze Ratio Gruppe";
 theUILang.mnuRatioUnlimited	= "Keine Ratio";
 theUILang.ratioName		= "Name";
 theUILang.minRatio		= "Min.";
 theUILang.maxRatio		= "Max.";
 theUILang.ratioUpload		= "UL";
 theUILang.ratioAction		= "Aktion";
 theUILang.ratioStop		= "Stop";
 theUILang.ratioStopAndRemove	= "Stop & Gruppe entfernen";
 theUILang.ratioErase		= "Entfernen";
 theUILang.ratioEraseData	= "Daten löschen";
 theUILang.maxTime		= "Zeit";
 theUILang.ratioDefault 	= "Stadart Ratio Gruppe";
 theUILang.setThrottleTo	= "Ändere Channel zu";

thePlugins.get("ratio").langLoaded();