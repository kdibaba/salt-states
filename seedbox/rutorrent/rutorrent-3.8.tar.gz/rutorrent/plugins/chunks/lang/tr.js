﻿/*
 * PLUGIN CHUNKS
 *
 * Turkish language file.
 *
 * Author: 
 */

 theUILang.Chunks		= "Chunks";
 theUILang.cAvail		= "Availability";
 theUILang.cDownloaded		= "Downloaded";
 theUILang.cMode		= "Mode";
 theUILang.chunksCount		= "Chunks count";
 theUILang.chunkSize		= "Chunk size";
 theUILang.cLegend		= "Legend";
 theUILang.cLegendVal		= [ "4 chunks per cell", "1 chunk per cell" ];

thePlugins.get("chunks").langLoaded();