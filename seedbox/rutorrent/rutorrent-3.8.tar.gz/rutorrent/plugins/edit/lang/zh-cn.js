﻿/*
 * PLUGIN EDIT
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.EditTrackers 		= "编辑 Torrent...";
 theUILang.EditTorrentProperties	= "Torrent 属性";
 theUILang.errorAddTorrent		= "添加 torrent 文件时出错";
 theUILang.errorWriteTorrent		=  "写 torrent 文件时出错";
 theUILang.errorReadTorrent		= "读 torrent 文件时出错";
 theUILang.cantFindTorrent		= "这个下载的 torrent 源文件未找到."

thePlugins.get("edit").langLoaded();
