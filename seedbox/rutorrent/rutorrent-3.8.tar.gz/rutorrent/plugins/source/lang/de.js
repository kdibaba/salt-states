﻿/*
 * PLUGIN SOURCE
 *
 * German language file.
 *
 * Author: Dario Rugani (kontakt@rugani.de)
 */

 theUILang.getSource		= "Hole .torrent";
 theUILang.cantFindTorrent	= "Quell Torrent-Datei für diesen Download nicht gefunden.";

thePlugins.get("source").langLoaded();