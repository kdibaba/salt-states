﻿/*
 * PLUGIN FEEDS
 *
 * Greek language file.
 *
 * Author: Chris Kanatas (ckanatas@gmail.com)
 */

 theUILang.feedAll		= "Όλα τα torrents";
 theUILang.feedCompleted	= "Ολοκληρωμένα torrents";
 theUILang.feedDownloading	= "Torrents σε λήψη";
 theUILang.feedActive		= "Ενεργά torrents";
 theUILang.feedInactive 	= "Ανενεργά torrents";
 theUILang.feedError		= "Torrents με σφάλμα";

thePlugins.get("feeds").langLoaded();