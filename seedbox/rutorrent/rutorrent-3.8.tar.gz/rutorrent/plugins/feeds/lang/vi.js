﻿/*
 * PLUGIN FEEDS
 *
 * Vietnamese language file.
 *
 * Author: Ta Xuan Truong (truongtx8 AT gmail DOT com)
 */

 theUILang.feedAll		= "Tất cả Torrent";
 theUILang.feedCompleted	= "Torrent đã hoàn thành";
 theUILang.feedDownloading	= "Torrent đang tải";
 theUILang.feedActive		= "Torrent đang hoạt động";
 theUILang.feedInactive 	= "Torrent không hoạt động";
 theUILang.feedError		= "Torrent lỗi";

thePlugins.get("feeds").langLoaded();