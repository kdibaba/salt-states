﻿/*
 * PLUGIN UploadETA
 *
 * Greek language file.
 *
 * Author: 
 */

 theUILang.uploadeta		= "ETA Αποστολής";
 theUILang.uploadtarget		= "Προορισμός Αποστολής";
 theUILang.ULtarget		= "Προορισμός UL";
 theUILang.ULremaining		= "Εναπομείναν UL";
 theUILang.ULETA		= "UL ETA";
 theUILang.ULdescription	= "Αυτό το πρόσθετο δείχνει μόνο το μέγεθος των δεδομένων και το χρόνο που απομένει μέχρι να ολοκληρωθεί η αναλογία αποστολής που έχετε θέσει. Δεν αφαιρεί αυτόματα το torrent όταν επιτευκτεί η αναλογία. Ελέγξτε την παράμετρο 'ratio.min.set' στο αρχείο παραμετροποίησης του rTorrent σας αν θέλετε να σβήνεται το torrent όταν επιτευκτεί η αναλογία που έχετε θέσει.";

thePlugins.get("uploadeta").langLoaded();
