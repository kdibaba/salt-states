<?php
	// configuration parameters

	$updateInterval = 15;				// in minutes, 1-6,10,12,15,20,30 or 60
	$collectStatForTorrents = true;
	$disableClearButton = false;

	$storeDeletedTorrentsStatsDuring = 2592000;	// in seconds
