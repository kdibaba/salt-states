<?php
	// configuration parameters

	$retrieveCountry = true;
	$retrieveHost = true;
	$retrieveComments = true;

	// For retrieve hosts

	$dnsResolver = '8.8.8.8';	// use gethostbyaddr, if null
	$dnsResolverTimeout = 1;	// timeout in seconds