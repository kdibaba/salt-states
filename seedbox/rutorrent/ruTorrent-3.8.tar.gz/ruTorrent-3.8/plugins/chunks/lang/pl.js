﻿/*
 * PLUGIN CHUNKS
 *
 * Polish language file.
 *
 * Author: 
 */

 theUILang.Chunks		= "Części";
 theUILang.cAvail		= "Dostępność";
 theUILang.cDownloaded		= "Pobranych";
 theUILang.cMode		= "Tryb";
 theUILang.chunksCount		= "Ilość części";
 theUILang.chunkSize		= "Rozmiar części";
 theUILang.cLegend		= "Legenda";
 theUILang.cLegendVal		= [ "4 części na komórkę", "1 część na komórkę" ];

thePlugins.get("chunks").langLoaded();
