﻿/*
 * PLUGIN CHECK_PORT
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.checkPort		= "检查端口状态";
 theUILang.portStatus		= [
 				  "端口状态未知",
 				  "端口是关闭的",
 				  "端口是开放的"
 				  ];

thePlugins.get("check_port").langLoaded();
