﻿/*
 * PLUGIN ERASEDATA
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.Rem_torrents_content_prompt		= "Вы действительно хотите удалить выбранные торрент(ы)? ВНИМАНИЕ: Содержимое торрента будет удалено.";
 theUILang.Delete_data_with_path		= "Удалить директорию";
 theUILang.Rem_torrents_with_path_prompt	= "Вы действительно хотите удалить выбранные торрент(ы)? ВНИМАНИЕ: Все данные в корневой директории торрента будут удалены.";

thePlugins.get("erasedata").langLoaded();