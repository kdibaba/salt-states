﻿/*
 * PLUGIN COOKIES
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (oleksandr@natalenko.name)
 */

 theUILang.cookiesDesc = "Файли cookie (Формат: вузол|cookie1;cookie2…)";
 theUILang.cookiesName = "Файли cookie";

thePlugins.get("cookies").langLoaded();
